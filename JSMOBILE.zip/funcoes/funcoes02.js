//DECLARAÇAO OU CRIAÇAO
//function soma(n1, n2){
//   if(typeof n1 === 'number' && typeof n2 === 'number'){
//   const res= n1 + n2;
//   alert('O resultado foi: ' + res)}else{alert('Por favor insira um número válido')}
// }


//CHAMADA OU INVOCAO
//soma("maça", 3)
//soma(4, 5)
//soma(10, 20)

// function dados(nome, sobrenome){
//   if(typeof nome === 'string' && typeof sobrenome === 'string'){      
//       alert('Olá ' + nome +" " + sobrenome + "!")
//     }else{alert( ' Por favor insira um texto válido')}
// }
// dados( 'Flávio', 'Souza')
// dados(12,'matheus')
// dados(12,67)


// function dados(nome, altura){
//   if(typeof nome === 'string' && typeof altura === 'number'){      
//       alert('Olá ' + nome + 'sua altura é :' + altura + "!")
//     }else{alert( ' Por favor insira um texto válido')}
// }
// dados( 'Flávio', 1.80)
// dados(12,'matheus')
// dados(12,67)

function dados(n) {
  if (typeof n === 'number') {
    if (n % 2 === 0) {
      alert(' O número ' + n + ' é par ')
    } else { alert(' O número ' + n + ' é impar ') }
  
} else {
  alert('Por favor insira um número válido')
}
}
dados(12)
dados(13)
dados("oi")

