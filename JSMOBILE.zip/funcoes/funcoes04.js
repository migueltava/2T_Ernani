// FUNCOES COM RETORNO
// SAO FUNCOES QUE PERMITEM RETER O VALOR PROCESSADO
// PARA UM USO POSTERIOR

// const nome = 'Flávio'
// function retornaDados() {
//   //CÓDIGO RETORNO
//   return nome.toUpperCase()
//   console.log('testando...')
//   // A PARTIR DESSA LINHA N EXECUTA MAIS NADA...
// }
// const dados = retornaDados()
// console.log(dados)


function retornaDados(nome, idade, cpf) {
  return 'Olá ' + nome + ' Sua idade é ' + idade + ' Seu cpf é ' + cpf + "!"
}
const dados = retornaDados('Miguel', 18, 123456789 - 34)
console.log(dados)