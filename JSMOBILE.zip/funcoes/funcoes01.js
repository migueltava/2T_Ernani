/**
 * funçoes; sao blocos de codio que podem ser reaproveitados
 * funçoes; podm ou nao ter nmes
 * funçoes:podem ou nao ter parametros
 */
//criar ou delatar funçoe//
function dizOla() {
  //codigo
  console.log('Olá!')
}
//invocar/chamar funçoes
//dizOla('Flávio')
//dizOla('Ana')
//dizOla('João')

//adiçao
function somaDoisNumeros(a, b) {
  const soma = a + b
  console.log(soma)
}
somaDoisNumeros(2, 3)
somaDoisNumeros(4, 5)

//subtraçao
function subtraiDoisNumeros(a, b) {
  const subtraçao = a - b
  console.log(subtraçao)
}
subtraiDoisNumeros(20, 3)
subtraiDoisNumeros(4, 1)

//multiplicaçao
function multiplicaDoisNumeros(a, b) {
  const multiplica = a * b
  console.log(multiplica)
}
multiplicaDoisNumeros(10, 3)
multiplicaDoisNumeros(4, 23)

//divisao
//multi
plicaçao
function divideDoisNumeros(a, b) {
  const divide = a / b
  console.log(divide)
}
divideDoisNumeros(10, 2)
divideDoisNumeros(55, 5)

