const btnAlternar = document.getElementById('btn-alternar')
const imgLampada = document.getElementById('lampada')
const baseUrl = "https://fc9a87b5-aa23-4080-92e7-7215da61fd31-00-1b5od0kpxa623.kirk.replit.dev/"
btnAlternar.addEventListener('click', function() {

  if (imgLampada.src == baseUrl + "lampada0.png") {
    imgLampada.src = "lampada2.png"
  } else {
    imgLampada.src = "lampada0.png"
  }

})

