//selecionar elementos html
//
const color = document.querySelector('#color');
const linha = document.querySelector('.linha');
const range = document.querySelector('#range');
const box = document.querySelector('.box');
const valorCor = document.querySelector('.valor-cor');

range.value = 0;
range.addEventListener('input', function() {
  box.style.borderRadius = range.value + 'px';
})

color.addEventListener('input', function() {
  box.style.backgroundColor = color.value;
  valorCor.innerText = color.value;
  valorCor.style.color = "white"
})


//alert(color.value)


//criar elementos de manipulaçao