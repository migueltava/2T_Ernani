//ARRAY OU LISTA DE VALORES
const prod1 ="Camisa"
const prod2 ="Bermuda"
const prod3 ="Calça"


const produtos=["Camisa", "Bermuda", "Calça","Sapato"]
//                0          1         2          3
const preço = [10.99, 20, 30, 40.99]
produtos[5]// undefined- indeinido
produtos[5] ="Boné"
produtos[2]// Camisa
//SAIDA DE DADOS (alert, console.log, innerHTML)
console.log(produtos[0])
console.log(produtos[1])
console.log(preço[2])
console.log(preço[3])
console.log(preço[5])