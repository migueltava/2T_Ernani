//METODOS ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'sushi'//MANUAL
comidas.push('tofu')//EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop()//RETIRAR UM VALOR DO FINAL DA LISTA
comidas.shift()//RETIRAR UM ELEMENETO DO INICIO DA LISTA
comidas.unshift('pão')//INSERIR UM ITEM NO INICIO DA LISTA

console.log(comidas.length)

const tamanho = comidas.length
console.log(" Existem "  + tamanho+ " itens na lista ")// CONTAGEM DE ITENS

console.log(comidas)