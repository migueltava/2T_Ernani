// objeto
/**
 * criar variaveis e usa-las
*/
const titulo = document.getElementById("titulo");
const paragrafo = document.getElementById("paragrafo");
// minhas variaveis
const novoTitulo = "titulo modificado";
const novoParagrafo = "paragrafo modificado";

titulo.innerText = novoTitulo
paragrafo.innerText = novoParagrafo

//array ou lista
//arrays sao organizados a partir do 0
// () {} []
const roupa = 'Camiseta'
const roupas = ['Camiseta', 'Calça', 'Vestido', 'Blusa']
const precos = [10, 20, 30, 40]

const idades = [1, 25, 65, 28]
const misto = ['Manga', 33, 'Camaro', 'Brawl', false]
// acesar elemento array
//console.log(roupa)
//console.log(roupas)
//console.log(roupas[3])
//roupas[20]= 'Brownie'
//console.log(roupas[20])  

for (var i = 0; i <= 3; i++) {
  console.log(roupas[i])
}


for (var j = 0; j <= 3; j++) {
  console.log(precos[j])
}



