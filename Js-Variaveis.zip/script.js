/*
*DECLARAÇÃO DE VARIÁVEIS JAVASCRIPT
* identificador da variavél
valor: valor inicial da variável
*/
const nome = "João" //escopo global - mutável
const sobrenome = "da Silva" //escopo em bloco - mutável
const idade = 17; //escopo em bloco - imutável

//REATRIBUINDO VALORES
//pet = "Zac"
//nome = "Marmelada"
//pi = 32.5 vai dar erro porque é constante
const dadosPessoais = nome+" "+sobrenome+ " "+idade
const ano =2024
const anoNascimento = 1986
const idadeAtual = ano - anoNascimento
//
const num = 24
const ehPar = num % 2 == 0 // PAR
const ehImpar = num % 2 == 1 // IMPAR


if(ehPar){
  console.log("O número é par")
}else{
  console.log("o número é impar")
}


console.log(ehPar)
console.log(ehImpar)
//console.log( idadeAtual+ " anos" )//concatenar ou juntar valores










/** CRE UMA VARIAVÉL PARA CADA SSITUAÇÃO */
//passatempo;
//cidade;
//precoDolar;
//animalEtimaçao;
//estaSolteiro = false ou true
//todosOsDados (concatenr)


const passaTempo = "ver filmes" 
const cidade = " Curitiba"
const preçoDolar = 5.12;
const animalEstimacao = "cachorro"
const estaSolteiro = false
const todosOsDados = passaTempo+" "+cidade+" "+preçoDolar+" "+ animalEstimacao+" "+estaSolteiro
//console.log(todosOsDados)























