html {
  height: 100%;
  width: 100%;
  font-family: Verdana;
}

body {
  display: flex;
  height: 100%;
  background-color: #71c8fe;
  justify-content: center;
  align-items: center;
}

.cadastro {
  background-color: #fff;
  padding: 25px;
  border: 1px solid #ccc;
  border-radius: 12px;
}

.item-cadastro {
  maegin: 8px;
  list-style: none;
}